import java.util.ArrayList;


public class Frequent_Itemset {

	int support_count;
	ArrayList<String> itemset = new ArrayList<String>();
	
}
