
public class Association_Rule {
	Frequent_Itemset[] L;
	Frequent_Itemset itemset1;
	Frequent_Itemset itemset2;
	int support_count=0;
	
	

}
