import java.util.ArrayList;


public class Cluster {
	static int num_clusters = 0;
	int serial = -1;
	int size = 0;
	ArrayList<FeatureVec> members;
	FeatureVec mean;
	
	public Cluster(){
		members = new ArrayList<FeatureVec>();
		this.mean = new FeatureVec();
		serial = num_clusters;
		num_clusters++;
	}
	
	public Cluster(FeatureVec mean){
		members = new ArrayList<FeatureVec>();
		this.mean = new FeatureVec(mean);
		serial = num_clusters;
		num_clusters++;
	}
	
	public void addVec(FeatureVec v){
		members.add(v);
		if(v.cluster !=null)
			v.cluster.remVec(v);
		v.cluster = this;
		v.label = this.serial;
		size++;
	}
	
	public void remVec(FeatureVec v){
		members.remove(v);
		size--;
	}
	
	public double distortion(){
		double distortion = 0;
		for(FeatureVec member : members){
			distortion += FeatureVec.d(member, this.mean);
		}
		return Math.sqrt(distortion);
	}
	
	public double d(Cluster other){
		double min = Double.MAX_VALUE;
		for(FeatureVec membera : this.members)
			for(FeatureVec memberb : other.members){
				double d = FeatureVec.d(membera, memberb);
				if(d<min)
					min = d;
			}
		return min;
	}

	public void mergeClusters(Cluster other) {
		System.out.println("Merging Clusters");
		for(FeatureVec member : other.members){
			this.members.add(member);
			member.label = this.serial;
			member.cluster = this;
			this.size++;
		}
		other.size = 0;
		other.members = null;
		num_clusters --;
		
	}

	public void relableSerial(int i) {
		for(FeatureVec member: members){
			member.label = i;
		}
		this.serial = i;
		num_clusters = i;
		
	}
}
